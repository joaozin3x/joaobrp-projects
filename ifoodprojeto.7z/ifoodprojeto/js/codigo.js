const carrinho = [];

function alterarQuantidade(nome, preco, quantidade) {
  const index = carrinho.findIndex(item => item.nome === nome);
  if (index > -1) {
    carrinho[index].quantidade += quantidade;
    if (carrinho[index].quantidade <= 0) {
      carrinho.splice(index, 1);
    }
  } else if (quantidade > 0) {
    carrinho.push({ nome, preco, quantidade });
  }
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const lista = document.getElementById('lista-carrinho');
  const total = document.getElementById('total-carrinho');
  lista.innerHTML = '';
  let soma = 0;
  carrinho.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.nome} x${item.quantidade} – R$ ${(item.preco * item.quantidade).toFixed(2).replace('.', ',')}`;
    lista.appendChild(li);
    soma += item.preco * item.quantidade;
  });
  total.textContent = `Total: R$ ${soma.toFixed(2).replace('.', ',')}`;
}

function finalizarCompra() {
  if (carrinho.length === 0) {
    alert('Seu carrinho está vazio.');
    return;
  }
  alert('Pedido finalizado com sucesso!');
  carrinho.length = 0;
  atualizarCarrinho();
}

function loginUsuario() {
  alert('Login efetuado com sucesso!');
  return false;
}
